const upload = document.getElementById("imageUpload");
const result = document.getElementById("result");
const tips = document.getElementById("tips");
const preview = document.getElementById("imagePreview");
const canvas = document.getElementById("canvas");
const detectBtn = document.getElementById("detectBtn");

const shapeTips = {
  Round: "Try hairstyles that add height and volume on top.",
  Oval: "Most styles suit you! Try layered or curtain bangs.",
  Square: "Soft waves or side-swept bangs help soften sharp angles.",
  Heart: "Chin-length bobs or side parts can balance your forehead.",
  Diamond: "Styles that add width to the forehead and jawline work great.",
  Long: "Avoid height on top. Try volume on the sides."
};

Promise.all([
  faceapi.nets.tinyFaceDetector.loadFromUri('./models'),
  faceapi.nets.faceLandmark68Net.loadFromUri('./models')
]).then(() => {
  console.log("Models loaded.");
});

let currentImage = null;

upload.addEventListener("change", () => {
  const file = upload.files[0];
  if (!file) return;

  result.textContent = '';
  tips.textContent = '';
  preview.src = URL.createObjectURL(file);
  preview.style.display = "block";
  currentImage = file;
});

detectBtn.addEventListener("click", async () => {
  if (!currentImage) {
    alert("Please upload an image first.");
    return;
  }

  const image = await faceapi.bufferToImage(currentImage);
  preview.src = image.src;

  canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
  const detections = await faceapi.detectSingleFace(preview, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks();

  if (!detections) {
    result.textContent = "⚠️ No face detected. Please try another image.";
    tips.textContent = "";
    return;
  }

  const landmarks = detections.landmarks;
  const jaw = landmarks.getJawOutline();
  const cheekboneL = landmarks.positions[1];
  const cheekboneR = landmarks.positions[15];
  const chin = landmarks.positions[8];
  const forehead = landmarks.positions[27];

  const jawWidth = jaw[16].x - jaw[0].x;
  const cheekWidth = cheekboneR.x - cheekboneL.x;
  const faceLength = chin.y - forehead.y;

  let shape = "Unknown";
  const ratio = faceLength / cheekWidth;
  const jawRatio = jawWidth / cheekWidth;

  if (Math.abs(ratio - 1) < 0.2) {
    shape = jawRatio > 0.95 ? "Round" : "Square";
  } else if (ratio > 1.3 && jawRatio < 0.9) {
    shape = "Heart";
  } else if (jawRatio < 0.85) {
    shape = "Diamond";
  } else if (ratio > 1.5) {
    shape = "Long";
  } else {
    shape = "Oval";
  }

  result.textContent = `Detected Face Shape: ${shape}`;
  tips.textContent = shapeTips[shape] || "";

  const displaySize = { width: preview.width, height: preview.height };
  faceapi.matchDimensions(canvas, displaySize);
  const resized = faceapi.resizeResults(detections, displaySize);
  faceapi.draw.drawDetections(canvas, resized);
  faceapi.draw.drawFaceLandmarks(canvas, resized);
});
